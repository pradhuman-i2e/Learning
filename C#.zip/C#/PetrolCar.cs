class PetrolCar : NewCar
{
    public void Start()
    {
        Console.WriteLine("Starting a petrol car.");
    }
}