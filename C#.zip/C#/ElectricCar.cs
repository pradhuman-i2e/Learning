class ElectricCar : NewCar
{
    public void Start()
    {
        Console.WriteLine("Starting an electric car.");
    }
}