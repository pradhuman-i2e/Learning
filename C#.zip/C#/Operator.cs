

// class Operator
// {
    
//     public static int Add(int a, int b)
//     {
//         return a + b;
//     }

    
//     public static int Subtract(int a, int b)
//     {
//         return a - b;
//     }

    
//     public static int Multiply(int a, int b)
//     {
//         return a * b;
//     }

//     public static double Divide(int a, int b)
//     {
//         return (double)a / b;
//     }

//      public static void ShowOperators()
//     {
//         // Assignment Operators
//         int num = 10;
//         num += 5; // num = num + 5
//         num -= 3; // num = num - 3
//         num *= 2; // num = num * 2
//         num /= 4; // num = num / 4
//         num %= 3; // num = num % 3

//         Console.WriteLine($"Assignment Operators: num = {num}");

//         // Logical Operators
//         bool isPradhuman = true;
//         bool isI2E = false;

//         bool logicalAnd = isPradhuman && isI2E;
//         bool logicalOr = isPradhuman || isI2E;
//         bool logicalNot = !isPradhuman;

//         Console.WriteLine($"Logical AND: {logicalAnd}");
//         Console.WriteLine($"Logical OR: {logicalOr}");
//         Console.WriteLine($"Logical NOT: {logicalNot}");

//         // Comparison Operators
//         int x = 10, y = 20;

//         Console.WriteLine($"x == y: {x == y}");
//         Console.WriteLine($"x != y: {x != y}");
//         Console.WriteLine($"x > y: {x > y}");
//         Console.WriteLine($"x < y: {x < y}");
//         Console.WriteLine($"x >= y: {x >= y}");
//         Console.WriteLine($"x <= y: {x <= y}");
//     }


// }