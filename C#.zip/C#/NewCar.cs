interface NewCar
{
    void Start();
}