class Report
{
    public void GenerateReport(string data)
    {
        Console.WriteLine("Generating report for user: " + data);
    }
}